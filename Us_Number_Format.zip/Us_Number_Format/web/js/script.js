function number_Format()
{
    var txtnumber=document.getElementById("txtnum");
    var regex= new RegExp(/^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/);
    return regex.test(txtnumber.value);
}
